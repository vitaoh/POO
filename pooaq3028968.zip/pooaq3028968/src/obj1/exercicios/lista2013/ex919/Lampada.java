package obj1.exercicios.lista2013.ex919;

public interface Lampada {
    
    void ligar();
    void desligar();
    boolean estaLigada();
}
